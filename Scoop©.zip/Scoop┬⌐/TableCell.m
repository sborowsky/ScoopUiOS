//
//  Scoop©
//  Sam Borowsky
//  TableCell.m
//  The implementation file for the table cell controller
//  01.29.2015
//

#import "TableCell.h"

@implementation TableCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
