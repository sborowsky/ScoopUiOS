//
//  Scoop©
//  Sam Borowsky
//  DriversTableViewController.h
//  The header file for the avialable drivers table controller
//  01.29.2015
//

#import <UIKit/UIKit.h>

@interface DriversTableViewController : UITableViewController<UITableViewDataSource,
    UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *myTableView; //connection to the table view

@property (nonatomic, strong) NSArray *Images; //An array for images of the drivers
@property (nonatomic, strong) NSArray *Names; //An array for the names of the drivers
@property (nonatomic, strong) NSArray *Cars; //An array for the type of each car (make and model)
@property (nonatomic, strong) NSArray *Ratings; //An array for the drivers' ratings
@property (nonatomic, strong) NSArray *Availability;//An array for the availability status of each
                                                    //driver (yes=available, no=not available)


@end
