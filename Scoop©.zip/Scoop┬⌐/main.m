//
//  main.m
//  Scoop©
//
//  Created by Samuel Borowsky on 1/28/15.
//  Copyright (c) 2015 Sam Borowsky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScoopAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ScoopAppDelegate class]));
    }
}
