//
//  loggedIn.h
//  LoginUser
//
//  Created by Nick Barrowclough on 4/14/14.
//  Copyright (c) 2014 iSoftware Developers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface loggedIn : UIViewController

- (IBAction)logout:(id)sender;

@end
