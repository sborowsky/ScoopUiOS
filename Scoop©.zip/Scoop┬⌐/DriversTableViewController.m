//
//  Scoop©
//  Sam Borowsky
//  DriversTableViewController.m
//  The implementation file for the avialable drivers table controller
//  01.29.2015
//

#import "DriversTableViewController.h"
#import "TableCell.h"

@interface DriversTableViewController ()

@end

@implementation DriversTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    
    //Add values to the Names array -- these are our sample drivers
    _Names = @[@"Sam Borowsky",
               @"Cary Carabasi",
               @"Walker Helvey",
               @"Alex Fox",
               @"Russell Schmidt",
               @"John Smith",
               @"Matt Williams",
               @"James Jones",
               @"Mark Adams",
               @"Sarah West",];
    
    //Add values to the Cars array -- these are our sample cars
    _Cars = @[@"Toyota Rav4",
              @"GMC Yukon",
              @"Toyota 4Runner",
              @"Jeep Cherokee",
              @"Chevy Silverado",
              @"Lexus LS460",
              @"Inifiniti Q50",
              @"Mazda 6",
              @"Subaru Impreza",
              @"Hummer H2",];
    
    //Add values to the Images array -- these are images of our sample drivers
    _Images = @[@"Borowsky.jpg",
                @"Carabasi.jpg",
                @"Helvey.jpg",
                @"Fox.jpg",
                @"Schmidt.jpg",
                @"Smith.jpg",
                @"Williams.jpg",
                @"Jones.jpg",
                @"Adams.jpg",
                @"West.jpg",];
    
    //Add sample ratings corresponding to the drivers
    _Ratings = @[@"3.4/5",
                 @"3.0/5",
                 @"3.8/5",
                 @"4.7/5",
                 @"4.1/5",
                 @"2.3/5",
                 @"4.8/5",
                 @"3.5/5",
                 @"1.9/5",
                 @"2.7/5",];
    
    //Set sample availability status for each driver
    _Availability =@[@"Yes",
                     @"Yes",
                     @"No",
                     @"No",
                     @"Yes",
                     @"Yes",
                     @"Yes",
                     @"No",
                     @"Yes",
                     @"No",];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1; //There will be one section for the available drivers
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 6; //This will display 6 driver profiles, though ultimately we want to display all
              //the drivers that are available rather than this fixed number that I specify.
              //This will require me to figure out how to filter through the Availability array
              //to distinguish between the drivers that are available and those that are not available.
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    //locate the table cell that will be manipulated
    static NSString *CellIdentifier = @"TableCell";
    TableCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    
    //Each row is formatted to display the values at the corresponding indices
    //of the sample arrays generated in the viewDidLoad method.  For example, the first
    //row displays the values at the first index of all the arrays (name = "Sam Borowsky",
    //car = "Toyota Rav4", image = "Borowsky.jpg", rating = "3.4/5").
    int row = [indexPath row];
   
    cell.NameLabel.text = _Names[row]; //get the proper name
    cell.CarLabel.text = _Cars[row]; //get the proper car information
    cell.RatingLabel.text = _Ratings[row]; //get the proper rating
    cell.DriverImage.image = [UIImage imageNamed:_Images[row]]; //get the proper image

    return cell;

}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
