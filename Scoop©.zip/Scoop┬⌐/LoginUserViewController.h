//
//  LoginUserViewController.h
//  LoginUser
//
//  Created by Nick Barrowclough on 4/14/14.
//  Copyright (c) 2014 iSoftware Developers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginUserViewController : UIViewController


@property (weak, nonatomic) IBOutlet UIButton *registerBtn;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UITextField *reEnterPasswordField;
@property (weak, nonatomic) IBOutlet UIImageView *scoopLogo;

- (IBAction)registerUser:(id)sender;
- (IBAction)LoginUser:(id)sender;


@end

